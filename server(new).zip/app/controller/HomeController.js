const ErrorCode = require("../helper/httpsServerCode");
const StudentModel=require('../model/student')
class HomeController{

    async  homePage(req,res){
        try{
            res.render('add',{
                title:"home page",
            })

        }catch(error){
            console.log(error);
            

        }

    }
    async  edit(req,res){
        try{
            res.render('edit',{
                title:"edit page",
            })

        }catch(error){
            console.log(error);
            

        }

    }
    async  list(req,res){
        try{
            res.render('list',{
                title:"list page",
            })

        }catch(error){
            console.log(error);
            

        }

    }
    async  createstudent(req,res){
        try{
           console.log(req.body);
           

        }catch(error){
            console.log(error);
            

        }
        //  try{
        //             //console.log(req.body);
        //             const{name,email,phone,city}=req.body
        //             console.log('name',req.body.name);
                    
        //             const sdata=new StudentModel({
        //                 name,email,phone,city
        //             })
        //             if(!name||!email||!phone||!city){
        //                 return res.status(ErrorCode.Badreq).json({
        //                     status:false,
        //                     message:"All field required",
                            
        //                 })  
        //             }
        //             else if(name.length>20||name.length<5)
        //             {
        //                 return res.status(ErrorCode.Badreq).json({
        //                     status:false,
        //                     message:"name must be contain 5 charecters",
                            
        //                 })  
        
        //             }
        //             else if( phone.length<10||phone.length>10)
                    
        //                 {
        //                     return res.status(ErrorCode.Badreq).json({
        //                         status:false,
        //                         message:"phone number must be 10 digits",
                                
        //                     })  
            
        //                 }
                   
        //             const data=await sdata.save()
        
        //             return res.status(ErrorCode.Create).json({
        //                 status:true,
        //                 message:"student create successfully",
        //                 data:data
        //             })
                    
        //         }
        //         catch (error) {
        //             console.error(error); // Add this to inspect the full error
                
        //             if (error.code === 11000 && error.keyPattern && error.keyPattern.email) {
        //                 return res.status(ErrorCode.InternalServerError).json({
        //                     status: false,
        //                     message: "Email is already available"
        //                 });
        //             }
                
        //             // Default fallback error handler
        //             return res.status(ErrorCode.InternalServerError).json({
        //                 status: false,
        //                 message: "Something went wrong",
        //                 error: error.message
        //             });
        //         }

    }
    
}


module.exports=new HomeController()