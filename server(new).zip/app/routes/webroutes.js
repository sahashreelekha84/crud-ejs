const express=require('express')
const HomeController = require('../controller/HomeController')

const router=express.Router()




router.get('/',HomeController. list)
router.get('/add',HomeController.homePage)
router.post('/create',HomeController.createstudent)
router.get('/edit',HomeController.edit)





module.exports=router