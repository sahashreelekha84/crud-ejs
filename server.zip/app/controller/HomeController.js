// class HomeController{

//     async  homePage(req,res){
//         try{
//             res.render('index',{
//                 title:"home page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  appointment(req,res){
//         try{
//             res.render('appointment',{
//                 title:"appointment page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  about(req,res){
//         try{
//             res.render('about',{
//                 title:"about page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  contact(req,res){
//         try{
//             res.render('contact',{
//                 title:"contact page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  feature(req,res){
//         try{
//             res.render('feature',{
//                 title:"feature page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  service(req,res){
//         try{
//             res.render('service',{
//                 title:"service page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  team(req,res){
//         try{
//             res.render('team',{
//                 title:"team page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  testimonial(req,res){
//         try{
//             res.render('testimonial',{
//                 title:"testimonial page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
//     async  notfound(req,res){
//         try{
//             res.render('404',{
//                 title:"404 page",
//             })

//         }catch(error){
//             console.log(error);
            

//         }

//     }
// }


// module.exports=new HomeController()