const ErrorCode={
    Success:200,
    Create:201,
    InternalServerError:500,
    Badreq:400
}


module.exports=ErrorCode