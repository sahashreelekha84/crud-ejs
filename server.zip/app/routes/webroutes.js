// const express=require('express')
// const HomeController = require('../controller/HomeController')

// const router=express.Router()




// router.get('/',HomeController.homePage)
// router.get('/appointment',HomeController.appointment)
// router.get('/about',HomeController.about)
// router.get('/contact',HomeController.contact)
// router.get('/feature',HomeController.feature)
// router.get('/service',HomeController.service)
// router.get('/team',HomeController.team)
// router.get('/testimonial',HomeController.testimonial)
// router.get('/404',HomeController.notfound)



// module.exports=router